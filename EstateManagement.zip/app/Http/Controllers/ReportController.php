<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Estate;
use App\Models\User;
use App\Models\Category;
use App\Models\Work;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    
}
